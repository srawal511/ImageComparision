/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imagecomparision;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author KULDEEP
 */
public class ImageComparision {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        // TODO code application logic here
        
        float percentage = 0;
        String Newline;
        URL File_Path = ImageComparision.class.getResource("ListCSV.csv");
        File File_Name = new File(File_Path.getFile());

        BufferedReader csvReader = new BufferedReader(new FileReader(File_Name));
          PrintWriter pw = new PrintWriter(new File("Result.csv"));
          
           ArrayList<ArrayList> Result=new ArrayList<ArrayList>();
        while (( Newline = csvReader.readLine()) != null) 
                {
                   final long startTime = System.currentTimeMillis(); 
                    String similar = "Null";
                            String[] data = Newline.split(",");
                            String image1 = data[0] ; 
                            String image2 = data[1];
                           
                           
                            URL Image_Path = ImageComparision.class.getResource(image1); 
                            File ImagePath1 = new File(Image_Path.getFile()); 
                            BufferedImage biA = ImageIO.read(ImagePath1);
                            DataBuffer dbA = biA.getData().getDataBuffer();
                            int sizeA = dbA.getSize();

                            URL ImagePath = ImageComparision.class.getResource(image2); 
                            File ImagePath2 = new File(ImagePath.getFile()); 
                            BufferedImage biA2 = ImageIO.read(ImagePath2);
                            DataBuffer dbA2 = biA2.getData().getDataBuffer();
                            
                            int count = 0;
                           
                            for (int i = 0; i < sizeA; i++) 
                            {
                                if (dbA.getElem(i) == dbA2.getElem(i)) 
                                {
                                    count = count + 1;
                                }
                            }
final long endTime = System.currentTimeMillis();
final long elapsed = endTime - startTime;
percentage = (count * 100) / sizeA;
            if(percentage == 0)
                    similar = "1.0";
            if(percentage >=50&& percentage <= 90)
                    similar = "0.5";
            else
                if(percentage==100 || percentage >=90)
                    similar = "0";
        ArrayList<String> temp=new ArrayList<String>();
        temp.add(image1);
        temp.add(image2);
        temp.add(similar);
        temp.add(String.valueOf(elapsed));
          Result.add(temp);
        }
         StringBuilder csvWriter= new StringBuilder();
         csvWriter.append("Image1");
         csvWriter.append(",");
         csvWriter.append("Image2");
         csvWriter.append(",");
         csvWriter.append("Similar");
         csvWriter.append(",");
         csvWriter.append("Elapsed(In Seconds)");
         csvWriter.append("\n");
         
        for(int j=0; j<=Result.size()-1;j++)
        {
            for(int k=0;k <= Result.get(j).size()-1 ;k++)
            {
                csvWriter.append(Result.get(j).get(k));
                csvWriter.append(",");
            }
             csvWriter.append("\n");
        }
    pw.write(csvWriter.toString());
    pw.close();
    csvReader.close();
        System.out.println("Please Check your file under Project Folder");
    }
    
   
}
